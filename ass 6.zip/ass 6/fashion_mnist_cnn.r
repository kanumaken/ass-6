library(keras)
library(magrittr)   # for %>%

# Load data
fashion <- dataset_fashion_mnist()

# Unpack train and test sets
c(x_train, y_train) %<-% fashion$train
c(x_test, y_test) %<-% fashion$test

# Reshape and normalize
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1)) / 255
x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1)) / 255

# One-hot encode labels
y_train_cat <- to_categorical(y_train, 10)
y_test_cat <- to_categorical(y_test, 10)

# Define model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = 'relu', input_shape = c(28,28,1)) %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile model
model %>% compile(
  optimizer = 'adam',
  loss = 'categorical_crossentropy',
  metrics = 'accuracy'
)

# Train model
model %>% fit(
  x_train, y_train_cat,
  epochs = 5, batch_size = 64,
  validation_split = 0.1
)

# ---- PREDICTION FOR TWO TEST IMAGES ----

# Select two test images properly (first dimension: 1 and 2)
test_images <- x_test[c(1,2),,,,drop=FALSE]  # fix: ensure correct indexing

# Predict
predictions <- model %>% predict(test_images)

# Convert predictions to class indices
predicted_classes <- apply(predictions, 1, which.max) - 1  # adjust for R's 1-based indexing

# Actual labels
actual_labels <- y_test[c(1,2)]

# Print results
for (i in 1:2) {
  cat(sprintf("Image %d - Predicted: %d | Actual: %d\n", i, predicted_classes[i], actual_labels[i]))
}

